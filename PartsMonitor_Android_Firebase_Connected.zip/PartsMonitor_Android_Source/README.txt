Parts Monitor Android source
Package: com.jitendrahada.partsmonitor
Firebase configuration included.
This is the first Android shell around the current V3 UI. Production Firebase Auth/Firestore sync and offline conflict handling still need to be wired into the UI.
Build with Android Studio.
